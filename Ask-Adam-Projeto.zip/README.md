
# Ask-Adam 🕎

**Ask-Adam** é um sistema para criar estudos judaicos com auxílio de IA, utilizando modelos locais como o LLaMA3 via Ollama.

## ✡️ Funcionalidades

- Geração de estudos indutivos com perguntas e reflexões
- Upload e leitura de PDFs
- Exportação dos estudos em `.txt`, `.md` e `.pdf`
- Interface moderna com design temático judaico
- Totalmente offline, sem uso de nuvem

## 🚀 Como usar

```bash
pip install -r requirements.txt
streamlit run main.py
```

Acesse via: [http://localhost:8501](http://localhost:8501)

## 📂 Estrutura

```
Ask-Adam/
├── main.py
├── src/
│   └── EBIagent.py
├── .env
├── requirements.txt
└── estudos_salvos/
```

## 📜 Licença

MIT - Compartilhe com sua comunidade! 🤝
