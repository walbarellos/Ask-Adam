# main.py simplificado, versão com melhorias visuais e template judaico
import os
import sys
import datetime
import streamlit as st
from dotenv import load_dotenv
from fpdf import FPDF

# Importações customizadas
sys.path.append('./src')
from EBIagent import EBIagent

# Configuração inicial
load_dotenv()
st.set_page_config(page_title="Estudo Judaico Indutivo", layout="wide")

# Parâmetros fixos do agente
params = {
    "versao_biblia": "Tanakh (Judaico)",
    "publico": "judeus religiosos modernos",
    "linguagem": "formal e respeitosa",
    "base_fe": "judaica tradicional"
}

agente = EBIagent(params)

# Estilo customizado
st.markdown("""
    <style>
    .stApp { background-color: #fdfcf7; }
    h1 { color: #2c3e50; font-family: 'Georgia'; }
    .block-container { padding-top: 2rem; }
    .titulo { font-size: 48px; color: #2c3e50; font-weight: bold; }
    .subtitulo { font-size: 20px; color: #555; }
    </style>
""", unsafe_allow_html=True)

st.markdown('<div class="titulo">📖 Estudo Judaico Indutivo</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitulo">Explorações profundas com base no Tanakh e tradição judaica</div>', unsafe_allow_html=True)
st.markdown("---")

query = st.text_input("🔎 Digite uma pergunta ou tema para estudo:", "")

def salvar_estudo(titulo, conteudo, formato="txt"):
    pasta = "estudos_salvos"
    os.makedirs(pasta, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    nome = f"{timestamp}_{titulo.replace(' ', '_')[:30]}"
    caminho = f"{pasta}/{nome}.{formato}"

    if formato == "txt":
        with open(caminho, "w", encoding="utf-8") as f:
            f.write(conteudo)
    elif formato == "md":
        with open(caminho, "w", encoding="utf-8") as f:
            f.write(f"# {titulo}\n\n{conteudo}")
    elif formato == "pdf":
        pdf = FPDF()
        pdf.add_page()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.set_font("Arial", size=12)
        for linha in conteudo.split("\n"):
            pdf.multi_cell(0, 10, linha)
        pdf.output(caminho)
    return caminho

if query:
    with st.spinner("🕎 Gerando estudo..."):
        resposta = agente.perguntar(query)
        st.markdown("### ✨ Estudo Gerado")
        st.markdown(resposta)

        with st.expander("💾 Salvar estudo"):
            formato = st.selectbox("Formato:", ["txt", "md", "pdf"])
            if st.button("Salvar"):
                caminho = salvar_estudo(query, resposta, formato)
                st.success(f"Estudo salvo em: {caminho}")

# Upload de PDF
st.markdown("---")
st.markdown("#### 📄 Ou envie um PDF para análise:")
arquivo_pdf = st.file_uploader("PDF", type=["pdf"])

if arquivo_pdf:
    with st.spinner("📚 Processando PDF..."):
        resposta = agente.processar_pdf(arquivo_pdf)
        st.markdown("### ✨ Resultado do PDF")
        st.markdown(resposta)
