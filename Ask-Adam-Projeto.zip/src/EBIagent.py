import requests
import fitz

class EBIagent:
    def __init__(self, params):
        self.params = params

    def montar_prompt(self, prompt):
        return f"""
Você é um mestre judeu tradicional, especializado em ensinar {self.params['versao_biblia']} para {self.params['publico']} com linguagem {self.params['linguagem']}, segundo a fé {self.params['base_fe']}.
Crie um estudo indutivo baseado no seguinte texto ou tema: "{prompt}"

1. Explique o conteúdo de forma resumida e respeitosa.
2. Crie 10 perguntas (observação, interpretação e aplicação).
3. Finalize com um versículo de reflexão (conectado ao tema).

Sempre escreva de forma fiel à tradição judaica.
"""

    def chat_ollama(self, prompt, modelo="llama3"):
        payload = {
            "model": modelo,
            "prompt": self.montar_prompt(prompt),
            "stream": False
        }
        try:
            response = requests.post("http://localhost:11434/api/generate", json=payload)
            response.raise_for_status()
            return response.json()["response"]
        except Exception as e:
            return f"Erro com Ollama: {e}"

    def perguntar(self, texto):
        return self.chat_ollama(texto)

    def processar_pdf(self, arquivo_pdf):
        try:
            doc = fitz.open(stream=arquivo_pdf.read(), filetype="pdf")
            texto = ""
            for pagina in doc:
                texto += pagina.get_text()
                if len(texto) > 1000:
                    break
            return self.chat_ollama(texto)
        except Exception as e:
            return f"Erro ao processar PDF: {e}"
